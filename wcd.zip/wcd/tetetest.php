<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>無題ドキュメント</title>
</head>

<body>
<p>The time is now <?php echo 'Hello, world'; ?>.</p>
</body>
</html>